# Optical RL-Gym

In this folder, you will find a few examples of how to use the Optical RL-Gym in combination with Stable Baselines' agents.

Before running the examples, make sure to install the Optical RL-Gym and the Stable Baselines in your Python environment.
