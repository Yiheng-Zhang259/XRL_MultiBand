from setuptools import setup

setup(name='optical_rl_gym',
      version='0.0.1-alpha',
      install_requires=['gym', 'numpy', 'matplotlib', 'networkx']
)
